import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import dotenv from "dotenv";
import nodemailer from "nodemailer";
import { initializeApp, getApps, getApp } from "firebase/app";
import { getFirestore, collection, query, where, getDocs, limit, doc, getDoc } from "firebase/firestore";

// Load environment variables
dotenv.config();

const firebaseConfig = {
  apiKey: "AIzaSyBYg3m4WgWR2Wcj5rVIR5LxEBmGZw0xtPU",
  authDomain: "printing-manager-9a6d2.firebaseapp.com",
  projectId: "printing-manager-9a6d2",
  storageBucket: "printing-manager-9a6d2.firebasestorage.app",
  messagingSenderId: "540298445964",
  appId: "1:540298445964:web:026f95e38794fb9aef27a9",
  measurementId: "G-HCTKFQLY17"
};

// Initialize Firebase for server-side queries
const serverFbApp = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
const serverDb = getFirestore(serverFbApp);

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  app.use(express.json());

  // API Routes (Can be added here for non-database related backend logic if needed)
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // Username to Email Resolver Endpoint
  app.get("/api/resolve-username", async (req: any, res: any) => {
    const { username } = req.query;
    if (!username || typeof username !== "string") {
      return res.status(400).json({ error: "username is required" });
    }

    const cleanUsername = username.trim().toLowerCase();
    
    if (cleanUsername === "tekkisandereagan" || cleanUsername === "reagan") {
      return res.json({ email: "tekkisandereagan@gmail.com" });
    }
    if (cleanUsername === "kulyakosukusandereagan") {
      return res.json({ email: "kulyakosukusandereagan@gmail.com" });
    }

    // Try username_map document lookup first (allows unauthenticated guest fetch bypassing list restrictions)
    try {
      const mapDocRef = doc(serverDb, "username_map", cleanUsername);
      const mapSnap = await getDoc(mapDocRef);
      if (mapSnap.exists()) {
        const data = mapSnap.data();
        if (data && data.email) {
          console.log(`[Server Username Resolver] Resolved via username_map: ${cleanUsername} to ${data.email}`);
          return res.json({
            email: data.email.trim().toLowerCase(),
            storedPassword: data.storedPassword || null,
            previousPassword: data.previousPassword || null
          });
        }
      }
    } catch (mapErr) {
      console.warn("[Server Username Resolver] username_map check warning (falling back):", mapErr);
    }

    try {
      const q = query(
        collection(serverDb, "users"), 
        where("username", "==", cleanUsername),
        limit(1)
      );
      const snapshot = await getDocs(q);
      
      if (!snapshot.empty) {
        const userData = snapshot.docs[0].data();
        if (userData.email) {
          console.log(`[Server Username Resolver] Resolved ${cleanUsername} to ${userData.email}`);
          return res.json({ 
            email: userData.email.trim().toLowerCase(),
            storedPassword: userData.password || null,
            previousPassword: userData.previous_password || null
          });
        }
      }

      const q2 = query(
        collection(serverDb, "users"), 
        where("email", "==", cleanUsername),
        limit(1)
      );
      const snapshot2 = await getDocs(q2);
      if (!snapshot2.empty) {
        const userData = snapshot2.docs[0].data();
        if (userData.email) {
          return res.json({ 
            email: userData.email.trim().toLowerCase(),
            storedPassword: userData.password || null,
            previousPassword: userData.previous_password || null
          });
        }
      }

      console.log(`[Server Username Resolver] Could not resolve ${cleanUsername}`);
      return res.json({ email: null, storedPassword: null, previousPassword: null });
    } catch (err: any) {
      console.error("[Server Username Resolver] Error:", err);
      return res.status(500).json({ error: err.message });
    }
  });

  // Twilio WhatsApp OTP API Endpoint
  app.post("/api/send-whatsapp-otp", async (req: any, res: any) => {
    const { username, otp, phone, deviceDetails } = req.body;
    
    if (!otp) {
      return res.status(400).json({ error: "OTP is required" });
    }

    const sid = process.env.TWILIO_ACCOUNT_SID;
    const token = process.env.TWILIO_AUTH_TOKEN;
    const from = process.env.TWILIO_WHATSAPP_FROM;
    const fallbackTo = process.env.ADMIN_WHATSAPP_NUMBER || "whatsapp:+256700000000";

    // Determine target recipient (format: must start with "whatsapp:")
    let recipient = phone || fallbackTo;
    if (recipient && !recipient.startsWith("whatsapp:")) {
      recipient = `whatsapp:${recipient}`;
    }

    const bodyText = `⚠️ ARK Printers Login Security Alert!\n\nAn account (${username}) is trying to log in from a new device/browser:\n- Device info: ${deviceDetails || "Unknown"}\n- Date/Time: ${new Date().toLocaleString()}\n\n🔑 YOUR CONFIRMATION OTP CODE IS: ${otp}\n\nIf this wasn't you, please change your password immediately.`;

    console.log(`[Twilio OTP Send Request] to: ${recipient}, OTP: ${otp}`);

    if (!sid || !token || !from) {
      console.warn("⚠️ Twilio is not fully configured (missing SID, Token, or From). SIMULATING WhatsApp message delivery.");
      return res.json({
        success: true,
        simulated: true,
        message: "SMS Simulated successfully (Twilio credentials not set).",
        recipient,
        body: bodyText
      });
    }

    try {
      const twilioUrl = `https://api.twilio.com/2010-04-01/Accounts/${sid}/Messages.json`;
      const authHeader = `Basic ${Buffer.from(`${sid}:${token}`).toString("base64")}`;

      const params = new URLSearchParams();
      params.append("From", from);
      params.append("To", recipient);
      params.append("Body", bodyText);

      const twilioResponse = await fetch(twilioUrl, {
        method: "POST",
        headers: {
          "Authorization": authHeader,
          "Content-Type": "application/x-www-form-urlencoded"
        },
        body: params.toString()
      });

      const responseData: any = await twilioResponse.json();

      if (twilioResponse.ok) {
        return res.json({
          success: true,
          simulated: false,
          sid: responseData.sid
        });
      } else {
        console.error("Twilio API Error response:", responseData);
        return res.json({
          success: true,
          error: responseData.message || "Twilio request failed",
          simulated: true,
          fallbackReason: "Twilio API returned error code",
          recipient,
          body: bodyText
        });
      }
    } catch (err: any) {
      console.error("Failed to connect to Twilio API:", err);
      return res.json({
        success: true,
        error: err.message,
        simulated: true,
        fallbackReason: "Twilio network connection failed",
        recipient,
        body: bodyText
      });
    }
  });

  // Gmail / Email OTP API Endpoint
  app.post("/api/send-email-otp", async (req: any, res: any) => {
    const { username, otp, email, deviceDetails } = req.body;
    
    if (!otp) {
      return res.status(400).json({ error: "OTP is required" });
    }

    const userEmail = email || "kulyakosukusandereagan@gmail.com";
    
    const bodyText = `⚠️ ARK Printers Login Security Alert!\n\nAn account (${username}) is trying to log in from a new device/browser:\n- Device info: ${deviceDetails || "Unknown"}\n- Date/Time: ${new Date().toLocaleString()}\n\n🔑 YOUR CONFIRMATION OTP CODE IS: ${otp}\n\nIf this wasn't you, please change your password immediately.`;

    const htmlText = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 25px; border: 1px solid #e2e8f0; border-radius: 16px; background-color: #ffffff; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);">
        <div style="text-align: center; border-bottom: 2px solid #f1f5f9; padding-bottom: 20px; margin-bottom: 20px;">
          <h2 style="color: #4f46e5; margin: 0; text-transform: uppercase; font-weight: 900; font-size: 22px; letter-spacing: 1px;">⚠️ ARK Printers</h2>
          <p style="color: #64748b; font-size: 12px; margin: 5px 0 0 0; text-transform: uppercase; font-weight: bold; letter-spacing: 0.5px;">Security Verification System</p>
        </div>
        <p style="color: #334155; font-size: 14px; line-height: 1.6; margin: 0 0 15px 0;">An account (<strong>${username}</strong>) is attempting to log in from a new device or browser environment:</p>
        <div style="background-color: #f8fafc; padding: 15px; border-radius: 12px; margin: 20px 0; border: 1px solid #f1f5f9;">
          <p style="margin: 5px 0; font-size: 13px; color: #475569;"><strong>Device/Browser:</strong> ${deviceDetails || "Unknown"}</p>
          <p style="margin: 5px 0; font-size: 13px; color: #475569;"><strong>Timestamp:</strong> ${new Date().toLocaleString()}</p>
        </div>
        <p style="color: #334155; font-size: 14px; margin-bottom: 15px;">Please use the following 6-digit confirmation code to complete your verification and authorize this device:</p>
        <div style="text-align: center; margin: 30px 0;">
          <span style="display: inline-block; font-family: 'Courier New', Courier, monospace; font-size: 34px; font-weight: 900; letter-spacing: 8px; padding: 15px 35px; background-color: #eef2ff; color: #4338ca; border: 1px solid #c7d2fe; border-radius: 12px;">
            ${otp}
          </span>
        </div>
        <p style="color: #94a3b8; font-size: 12px; text-align: center; margin: 20px 0 0 0; line-height: 1.6;">If you did not initiate this request, someone may be trying to access your account. Please update your master password immediately and contact administration.</p>
      </div>
    `;

    console.log(`[Email OTP Send Request] to: ${userEmail}, OTP: ${otp}`);

    // 1. HTTP-based transactional mail fallbacks (highly recommended for production deployments like Cloud Run)
    // HTTP API calls are never blocked by cloud run outbound firewalls/SMTP restrictions.
    
    // Fallback Option A: Resend HTTP API (Zero dependencies)
    if (process.env.RESEND_API_KEY) {
      try {
        console.log(`[Resend HTTP API Send Request] to: ${userEmail}`);
        const fromEmail = process.env.RESEND_FROM_EMAIL || "security@arkprinters.com";
        const resendResponse = await fetch("https://api.resend.com/emails", {
          method: "POST",
          headers: {
            "Authorization": `Bearer ${process.env.RESEND_API_KEY}`,
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            from: `ARK Printers Security <${fromEmail}>`,
            to: [userEmail],
            subject: "🔒 ARK Printers - Device Verification Code",
            html: htmlText
          })
        });
        
        if (resendResponse.ok) {
          const resendData: any = await resendResponse.json();
          console.log(`Email sent successfully via Resend API: ${resendData.id}`);
          return res.json({
            success: true,
            simulated: false,
            messageId: resendData.id,
            recipient: userEmail,
            provider: "resend"
          });
        } else {
          const errText = await resendResponse.text();
          console.error("Resend API failed, falling back to SMTP. Error:", errText);
        }
      } catch (resendErr: any) {
        console.error("Resend connection failed, falling back to SMTP:", resendErr);
      }
    }

    // Fallback Option B: SendGrid HTTP API (Zero dependencies)
    if (process.env.SENDGRID_API_KEY) {
      try {
        console.log(`[SendGrid HTTP API Send Request] to: ${userEmail}`);
        const fromEmail = process.env.SENDGRID_FROM_EMAIL || "security@arkprinters.com";
        const sgResponse = await fetch("https://api.sendgrid.com/v3/mail/send", {
          method: "POST",
          headers: {
            "Authorization": `Bearer ${process.env.SENDGRID_API_KEY}`,
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            personalizations: [{ to: [{ email: userEmail }] }],
            from: { email: fromEmail, name: "ARK Printers Security" },
            subject: "🔒 ARK Printers - Device Verification Code",
            content: [
              { type: "text/plain", value: bodyText },
              { type: "text/html", value: htmlText }
            ]
          })
        });

        if (sgResponse.ok) {
          console.log(`Email sent successfully via SendGrid API`);
          return res.json({
            success: true,
            simulated: false,
            recipient: userEmail,
            provider: "sendgrid"
          });
        } else {
          const errText = await sgResponse.text();
          console.error("SendGrid API failed, falling back to SMTP. Error:", errText);
        }
      } catch (sgErr: any) {
        console.error("SendGrid connection failed, falling back to SMTP:", sgErr);
      }
    }

    // 2. Standard Gmail SMTP Delivery (Nodemailer)
    const gmailUser = process.env.GMAIL_USER || "kulyakosukusandereagan@gmail.com";
    const gmailPass = process.env.GMAIL_APP_PASSWORD || "cyyizzbgqxomyqhg";

    if (!gmailUser || !gmailPass) {
      console.warn("⚠️ GMAIL_USER or GMAIL_APP_PASSWORD not set in environment. Running simulation mode.");
      return res.json({
        success: true,
        simulated: true,
        message: "Email simulated successfully (SMTP credentials missing in configuration).",
        recipient: userEmail,
        body: bodyText
      });
    }

    try {
      // Configure robust Gmail transporter utilizing TLS and bypass cert checks on strict cloud containers
      const transporter = nodemailer.createTransport({
        host: "smtp.gmail.com",
        port: 587,
        secure: false, // Use STARTTLS (highly recommended for Google Cloud/AWS platforms)
        auth: {
          user: gmailUser,
          pass: gmailPass
        },
        tls: {
          rejectUnauthorized: false // Bypasses node-level local trust-store SSL certificate errors in Docker/Cloud Run
        }
      });

      const mailOptions = {
        from: `"ARK Printers Security" <${gmailUser}>`,
        to: userEmail,
        subject: "🔒 ARK Printers - Device Verification Code",
        text: bodyText,
        html: htmlText
      };

      const info = await transporter.sendMail(mailOptions);
      console.log(`Email sent successfully via Gmail SMTP: ${info.messageId}`);

      return res.json({
        success: true,
        simulated: false,
        messageId: info.messageId,
        recipient: userEmail,
        provider: "gmail-smtp"
      });
    } catch (err: any) {
      console.error("Failed to send email via Gmail SMTP:", err);
      return res.json({
        success: true,
        error: err.message,
        simulated: true,
        fallbackReason: "SMTP delivery failed",
        recipient: userEmail,
        body: bodyText
      });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  const PORT = Number(process.env.PORT) || 3000;
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
